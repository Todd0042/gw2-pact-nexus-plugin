#pragma once
#include "SharedState.h"
#include <string>
#include <vector>

namespace LegendaryImpactEventmanager
{
    class ReminderService
    {
    public:
        explicit ReminderService(SharedState& sharedState);
        void CheckEventReminders(const PluginState& state);
        void ShowReminder(const std::string& title, const std::string& date, const std::string& tag, int minutesUntilStart);
        void CheckNewEventAnnouncements(const PluginState& state);
        void ShowNewEventsAnnouncement(const std::vector<EventItem>& events);
        void Render();

        void CloseReminderWindow();
        void CloseNewEventsWindow();
        void CloseAllWindows();
        bool IsAnyWindowOpen() const;

    private:
        SharedState& m_SharedState;
    };
}
